export const STUDENT_DATA_ACTION = "student_data_action";
