export default {

    //student list
    Distinction: "Distinction",
    FirstClass: "FirstClass",
    SecondClass: "SecondClass",
    Failed: "Failed",
    StudentList: "Student List",
    NoRecordsToDisplay: "No records to display.",
    Serach: "Serach",
    SearchStudent: "Search Student",
    Name: "Name:"
};
