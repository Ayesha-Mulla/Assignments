export const Configurations = {

    lang: 'EN',

    StudentListPath: "/",
    StudentDetailsPath: "/studentdetails",
};
